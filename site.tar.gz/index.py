import MySQLdb as db
import json

def get_db_connection():
		database = db.connect('localhost','root','S','applicationProcess')
		return database.cursor()

def login(data):
    return "recvd username and password "+data

def validate_pin(data):
		data_dict = json.loads(data)
		pin = data_dict["pin"]
		roll_no = data_dict["roll_no"]
		new_pass = data_dict["new_password"]
		query = "SELECT * FROM userIdDomain WHERE userId = '"+ roll_no +"';"
		result = perform_sql_action(query,'select')
		if len(result) == 1:
				if is_valid_pin(data):
						query = "insert into userPassword (userId,password) values ('"+roll_no+"','"+new_pass+"') ON DUPLICATE KEY UPDATE password='"+new_pass+"';"
						perform_sql_action(query, 'insert')
						return "new_password,success"

				else:
						return "pin,invalid," + pin
		else:
				return "rollno,invalid," + roll_no

def perform_sql_action(query, action):

		try:
				db_cur = get_db_connection()
				db_cur.execute(query)
				if(action == 'select'):
						result = db_cur.fetchall()
						db_cur.close()
						return result
				else:
						db_cur.commit()
						db_cur.close()
		except Exception as e:
				return "DatabaseError, "+str(e)




def is_valid_pin(data):
		return True
